using Blazor_Wsam_Standalone;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

// Default host end.
var builder = WebAssemblyHostBuilder.CreateDefault(args);

/*
 The HTML DOM interface to 'LoadComponent'aka the Renter Tree
The 'App' is root component theat manages :
1. RenderTree using UI Thread
2. All UI Changes
3. This is an interatciton with DOM UT thread from Blazor
    a. The Blazor object model is bound the UI thread using .Net web assembly through dotnet.js
        - JavaScript InterOp
 * */
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// DI - Used to make all registration available for UI Thread for each StateChange
// HttpClient

builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) }); // User the origin for Blazor wasm app to acccess Remote API

// Initialize the .Net Runtime and component to execure the app in broweser
await builder.Build().RunAsync();
