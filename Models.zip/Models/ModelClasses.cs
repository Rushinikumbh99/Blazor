﻿
/* An Attribute MetaData containder namespace that provide attriute claaes to verify datea*/
using System.ComponentModel.DataAnnotations;

namespace Blazor_Wsam_Standalone.Models
{
   

    public class Department 
    {
        [Required(ErrorMessage ="Dept No is Required")]
        public int DeptNo { get; set; }

        [Required(ErrorMessage = "DeptName is Required")]
        public string? DeptName { get; set; }

        [Required(ErrorMessage = "Location is Required")]
        public string? Location { get; set; }

        [Required(ErrorMessage = "Capacity is Required")]
        public int Capacity { get; set; }
        public List<Employee> Employees { get; set; } = new List<Employee>();
    }

    public class Employee 
    {
        [Required(ErrorMessage = "EmpNo is Required")]
        public int EmpNo { get; set;}

        [Required(ErrorMessage = "EmpName is Required")]
        public string? EmpName { get; set; }

        [Required(ErrorMessage = "Designation is Required")]
        public string? Designation { get; set; }

        [Required(ErrorMessage = "Salary is Required")]
        public int Salary { get; set; }

        [Required(ErrorMessage = "Dept No is Required")]
        public int DeptNo { get; set; }
        //public Department? Department    { get; set; } 
    }
}

