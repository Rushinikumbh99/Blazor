﻿namespace Blazor_Wsam_Standalone.Models
{
    public class Departments : List<Department>
    {
        public Departments()
        {
           Add(new Department() { DeptNo = 10, DeptName = "IT" });
           Add(new Department() { DeptNo = 20, DeptName = "HR" });
           Add(new Department() { DeptNo = 30, DeptName = "TRG" });
           Add(new Department() { DeptNo = 40, DeptName = "SALES" });
           
        }
    }

    public class Employees : List<Employee>
    {
        public Employees()
        {
            Add(new Employee() { EmpNo = 10, EmpName = "Emp-1", Designation = "Manager", DeptNo = 10, Salary = 123456 });
            Add(new Employee() { EmpNo = 20, EmpName = "Emp-2", Designation = "Director", DeptNo = 20, Salary = 2342343 });
            Add(new Employee() { EmpNo = 30, EmpName = "Emp-3", Designation = "Staff", DeptNo = 30, Salary = 20000 });
            Add(new Employee() { EmpNo = 40, EmpName = "Emp-4", Designation = "Manager", DeptNo = 40, Salary = 50000 });


        }
    }
}
